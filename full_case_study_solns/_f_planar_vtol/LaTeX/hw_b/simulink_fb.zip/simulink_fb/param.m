% initial conditions
P.z0 = 2.5;
P.zdot0 = 0;
P.h0 = 2;
P.hdot0 = 0;
P.theta0 = 0;
P.thetadot0 = 0;

% system parameters known to controller
P.mc = 1.0;  % kg
P.mr = 0.25;     % kg
P.Jc = 0.0042; %kg m^2
P.d = 0.3; % m
P.mu = 0.1; % kg/s
P.g = 9.81; % m/s^2

P.Fe = ((P.mc+2*P.mr)*P.g)/2;